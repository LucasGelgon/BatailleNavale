Le projet est terminé, l'exécution des trois fichiers et du jeu fonctionnent correctement.

L'intégralité des classes peuvent être testées et compilées.

Les deux bateaux prenant en paramètre le même fichier flotille.txt, les deux joueurs (client et serveur) ont leurs bateaux aux mêmes positions